﻿
namespace Example_TCP_Server
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("서버 콘솔창 \n\n\n");

            // TcpListener 생성자에 붙는 매개변수
            // 첫 번째 : 오픈할 서버 IP
            // 두 번째 : 오픈할 Port Number
            System.Net.Sockets.TcpListener server = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Any, 9999);

            // 서버를 시작합니다.
            server.Start();

            // 연결한 클라이언트를 받아옵니다.
            // 클라이언트 접속까지 서버는 기다립니다.
            System.Net.Sockets.TcpClient client = server.AcceptTcpClient();

            // Socket은 byte[] 형식으로 데이터를 주고 받으므로 byte[]형 변수를 선언합니다.
            byte[] byteData = new byte[1024];

            // 클라이언트가 write한 데이터를 Read합니다.
            // 데이터 Read까지 대기하고, Read 후 데이터는 byteData에 저장됩니다.
            client.GetStream().Read(byteData, 0, byteData.Length);

            // 저장된 byteData의 출력을 위해 string으로 변경합니다.
            System.Console.WriteLine(System.Text.Encoding.Default.GetString(byteData));

            server.Stop();
        }
    }
}
