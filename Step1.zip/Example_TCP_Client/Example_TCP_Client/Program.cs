﻿namespace Example_TCP_Client
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("클라이언트 콜솔창. \n\n\n");

            // 클라이언트 생성
            System.Net.Sockets.TcpClient client = new System.Net.Sockets.TcpClient();

            // TcpClient 생성자에 붙는 매개변수
            // 첫 번째 : 접속할 IP / 루프백IP : 127.0.0.1
            // 두 번째 : 접속할 서버에서 설정한 Port번호
            client.Connect("127.0.0.1", 9999);

            // 메세지를 stream으로 보내기 위해 byte형으로 변환합니다.
            byte[] buf = System.Text.Encoding.Default.GetBytes("클라이언트 : 접속합니다");

            // stream으로 변환한 메세지를 서버로 전송(Write)합니다.
            client.GetStream().Write(buf, 0, buf.Length);

            client.Close();
        }
    }
}
