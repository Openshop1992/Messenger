﻿using System;

namespace ChattingServiceConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleClient Client = new ConsoleClient();
            Client.Run();
        }
    }
}
