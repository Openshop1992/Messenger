﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChattingServiceConsoleClient
{
    class ConsoleClient
    {
        System.Net.Sockets.TcpClient client = null;
        System.Threading.Thread receiveMessageThread = null;
        System.Collections.Concurrent.ConcurrentBag<string> sendMessageListToView = null;
        System.Collections.Concurrent.ConcurrentBag<string> receiveMessageListToView = null;
        private string name = null;

        public void Run()
        {
            sendMessageListToView = new System.Collections.Concurrent.ConcurrentBag<string>();
            receiveMessageListToView = new System.Collections.Concurrent.ConcurrentBag<string>();
            receiveMessageThread = new System.Threading.Thread(receiveMessage);

            System.Console.WriteLine("==========클라이언트=========");
            System.Console.WriteLine("1.서버연결");
            System.Console.WriteLine("2.Message 보내기");
            System.Console.WriteLine("3.보낸 Message확인");
            System.Console.WriteLine("4.받은 Message확인");
            System.Console.WriteLine("5.쳇팅창 클리어");
            System.Console.WriteLine("0.종료");
            System.Console.WriteLine("=============================");

            while (true)
            {
                string key = System.Console.ReadLine();
                int order = 0;

                if (int.TryParse(key, out order))
                {
                    switch (order)
                    {
                        case StaticDefine.CONNECT:
                            {
                                if (client != null)
                                    System.Console.WriteLine("이미 연결되어있습니다.");
                                else
                                    Connect();

                                break;
                            }
                        case StaticDefine.SEND_MESSAGE:
                            {
                                if (client == null)
                                    System.Console.WriteLine("먼저 서버와 연결해주세요.");
                                else
                                    SendMessage();

                                break;
                            }
                        case StaticDefine.SEND_MSG_VIEW:
                            {
                                SendMessageView();
                                break;
                            }

                        case StaticDefine.RECEIVE_MSG_VIEW:
                            {
                                ReceiveMessageVIew();
                                break;
                            }
                        case StaticDefine.CHATTING_CLEAR:
                            {
                                System.Console.Clear();

                                System.Console.WriteLine("==========클라이언트=========");
                                System.Console.WriteLine("1.서버연결");
                                System.Console.WriteLine("2.Message 보내기");
                                System.Console.WriteLine("3.보낸 Message확인");
                                System.Console.WriteLine("4.받은 Message확인");
                                System.Console.WriteLine("5.쳇팅창 클리어");
                                System.Console.WriteLine("0.종료");
                                System.Console.WriteLine("=============================");
                                break;
                            }
                        case StaticDefine.EXIT:
                            {
                                if (client != null)
                                    client.Close();

                                receiveMessageThread.Abort();
                                return;
                            }
                    }
                }
                else
                {
                    System.Console.WriteLine("잘못 입력하셨습니다.");
                    System.Console.ReadKey();
                }
                System.Threading.Thread.Sleep(50);
            }
        }

        private void Connect()
        {
            System.Console.WriteLine("이름을 입력해주세요");

            name = System.Console.ReadLine();

            string parsedName = "%^&" + name;
            if (parsedName == "%^&")
            {
                System.Console.WriteLine("제대로된 이름을 입력해주세요");
                return;
            }

            System.Console.WriteLine("IP를 입력해주세요");

            string IP = System.Console.ReadLine();


            client = new System.Net.Sockets.TcpClient();
            // 여러개를 입력하려면 IP를 받아야 합니다.
            client.Connect(IP, 9999);

            byte[] byteData = new byte[1024];
            byteData = System.Text.Encoding.Default.GetBytes(parsedName);
            client.GetStream().Write(byteData, 0, byteData.Length);

            // 서버에 접속하고 서버의 메세지를 받아주는 스레드를 돌려줍니다.
            receiveMessageThread.Start();

            System.Console.WriteLine("서버연결 성공 이제 Message를 보낼 수 있습니다.");
        }


        private void ReceiveMessageVIew()
        {
            if (sendMessageListToView.Count == 0)
            {
                System.Console.WriteLine("받은 메세지가 없습니다.");
                return;
            }

            foreach (var item in receiveMessageListToView)
            {
                System.Console.WriteLine(item);
            }
        }

        private void SendMessageView()
        {
            if (sendMessageListToView.Count == 0)
            {
                System.Console.WriteLine("보낸 메세지가 없습니다.");
                return;
            }

            foreach (var item in sendMessageListToView)
            {
                System.Console.WriteLine(item);
            }
        }

        // 서버에서 보낸 메세지를 읽어주는 메서드이며 스레드를 생성해 돌려줍니다.
        private void receiveMessage()
        {
            string receiveMessage = "";
            System.Collections.Generic.List<string> receiveMessageList = new System.Collections.Generic.List<string>();

            while (true)
            {
                byte[] receiveByte = new byte[1024];
                client.GetStream().Read(receiveByte, 0, receiveByte.Length);

                receiveMessage = System.Text.Encoding.Default.GetString(receiveByte);

                string[] receiveMessageArray = receiveMessage.Split('>');
                foreach (var item in receiveMessageArray)
                {
                    if (!item.Contains('<'))
                        continue;

                    if (item.Contains("관리자<TEST"))
                        continue;

                    receiveMessageList.Add(item);
                }
                ParsingReceiveMessage(receiveMessageList);
            }
        }
        private void ParsingReceiveMessage(System.Collections.Generic.List<string> messageList)
        {
            foreach (var item in messageList)
            {
                string sender = "";
                string message = "";

                if (item.Contains('<'))
                {
                    string[] splitedMsg = item.Split('<');

                    sender = splitedMsg[0];
                    message = splitedMsg[1];

                    if (sender == "관리자")
                    {
                        string userList = "";
                        string[] splitedUser = message.Split('$');
                        foreach (var el in splitedUser)
                        {
                            if (string.IsNullOrEmpty(el))
                                continue;

                            userList += el + " ";
                        }
                        System.Console.WriteLine(string.Format("[현재 접속인원] {0}", userList));
                        messageList.Clear();
                        return;
                    }

                    System.Console.WriteLine(string.Format("[메세지가 도착하였습니다] {0} : {1}", sender, message));
                    receiveMessageListToView.Add(string.Format("[{0}] Sender : {1}, Message : {2}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), sender, message));
                }
            }
            messageList.Clear();
        }

        private void SendMessage()
        {
            string getUserList = string.Format("{0}<GiveMeUserList>", name);
            byte[] getUserByte = System.Text.Encoding.Default.GetBytes(getUserList);
            client.GetStream().Write(getUserByte, 0, getUserByte.Length);

            System.Console.WriteLine("수신자를 입력해주세요");
            string receiver = System.Console.ReadLine();

            System.Console.WriteLine("보낼 message를 입력해주세요");
            string message = Console.ReadLine();

            if (string.IsNullOrEmpty(receiver) || string.IsNullOrEmpty(message))
            {
                System.Console.WriteLine("수신자와 보낼 message를 확인해주세요");
                return;
            }

            string parsedMessage = string.Format("{0}<{1}>", receiver, message);

            byte[] byteData = new byte[1024];
            byteData = System.Text.Encoding.Default.GetBytes(parsedMessage);

            client.GetStream().Write(byteData, 0, byteData.Length);
            sendMessageListToView.Add(string.Format("[{0}] Receiver : {1}, Message : {2}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), receiver, message));
            System.Console.WriteLine("전송성공");
        }
    }
}
