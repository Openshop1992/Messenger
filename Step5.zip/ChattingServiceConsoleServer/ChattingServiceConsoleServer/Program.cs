﻿using System;

namespace ChattingServiceConsoleServer
{

    class Program
    {
        static void Main(string[] args)
        {
            MainServer Server = new MainServer();
            Server.ConsoleView();
        }
    }
}
