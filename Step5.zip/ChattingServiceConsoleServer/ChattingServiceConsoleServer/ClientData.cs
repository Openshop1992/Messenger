﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChattingServiceConsoleServer
{
    class ClientData
    {
        public System.Net.Sockets.TcpClient tcpClient { get; set; }
        public Byte[] readBuffer { get; set; }
        public System.Text.StringBuilder currentMsg { get; set; }
        public string clientName { get; set; }
        public int clientNumber { get; set; }

        public ClientData(System.Net.Sockets.TcpClient tcpClient)
        {
            currentMsg = new System.Text.StringBuilder();
            readBuffer = new byte[1024];
            this.tcpClient = tcpClient;
            char[] splitDivision = new char[2];
            splitDivision[0] = '.';
            splitDivision[1] = ':';
            string[] temp = null;


            temp = tcpClient.Client.LocalEndPoint.ToString().Split(splitDivision);
            this.clientNumber = int.Parse(temp[3]);
        }
    }
}
