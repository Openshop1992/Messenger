﻿namespace Example_TCP_Client
{
    class Program
    {
        System.Net.Sockets.TcpClient client = null;

        static void Main(string[] args)
        {
            Program Client = new Program();
            Client.Run();
        }

        public void Run()
        {
            ReadMe();

            // 클라이언트 생성
            while(true)
            {
                string strKey = System.Console.ReadLine();

                // 입력받은 Key값을 int.TypParse를 사용해 int형으로 변환합니다.
                // 형변환에 실패하면 false를 Retrun 합니다.
                int iOrder = 0;
                if (int.TryParse(strKey, out iOrder))
                {
                    switch (iOrder)
                    {
                        case 1:
                            if (client != null)
                            {
                                System.Console.WriteLine("이미 연결되어 있습니다.");
                                break;
                            }

                            Connect();
                            break;

                        case 2:
                            if (client == null)
                            {
                                System.Console.WriteLine("서버와 연결을 확인하세요.");
                                break;
                            }

                            sendMessage();
                            break;
                        case 3:
                            System.Console.Clear();
                            ReadMe();
                            break;
                        default:
                            System.Console.WriteLine("1, 2, 3 중 하나를 입력하세요.");
                            System.Console.Write("당신이 입력한 값은 : ");
                            System.Console.WriteLine(value: iOrder);
                            break;
                    }                       
                }
                else
                {
                    System.Console.Write("잘못된 값이 입력되었습니다. : ");
                    System.Console.WriteLine(value: strKey);
                }
                
            }
        }

        private void Connect()
        {
            System.Console.WriteLine("IP를 입력하세요");
            string strIP = System.Console.ReadLine();
            client = new System.Net.Sockets.TcpClient();
            client.Connect(strIP, 9999);
            System.Console.WriteLine("서버와 연결 성공 Message를 전송할 수 있습니다.");
        }
        private void sendMessage()
        {
            System.Console.WriteLine("전송할 메세지를 입력하세요.");

            string strMessage = System.Console.ReadLine();
            byte[] byteData = new byte[strMessage.Length];
            byteData = System.Text.Encoding.Default.GetBytes(strMessage);

            client.GetStream().Write(byteData, 0, byteData.Length);
            System.Console.Write("전송 성공 // 전송한 데이터 : ");
            System.Console.WriteLine(value: strMessage);
        }
        private void ReadMe()
        {
            System.Console.WriteLine("===클라이언트 콜솔창===");
            System.Console.WriteLine("1. 서버연결");
            System.Console.WriteLine("2. Message 보내기");
            System.Console.WriteLine("3. Message 창 Clear");
            System.Console.WriteLine("========================");
        }
        
    }
}
