﻿
namespace Example_TCP_Server
{
    class Program
    {
        static void Main(string[] args)
        {
            MyServer Server = new MyServer();
        }
    }


    class MyServer
    {
        public MyServer()
        {
            // 서버시작
            AsyncServerStart();
        }
        private void AsyncServerStart()
        {
            // TcpListener 생성자에 붙는 매개변수
            // 첫 번째 : 오픈할 서버 IP
            // 두 번째 : 오픈할 Port Number
            System.Net.Sockets.TcpListener listener = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Any, 9999);

            // 서버를 시작합니다.
            listener.Start();
            System.Console.WriteLine("서버를 시작합니다. 클라이언트의 접속을 기다립니다.");

            // 클라이언트 접속까지 서버는 기다립니다.
            System.Net.Sockets.TcpClient acceptClient = listener.AcceptTcpClient();
            System.Console.WriteLine("클라이언트가 접속했습니다.");

            // ClientData의 객체를 생성하고, 연결된 클라이언트를 ClientData의 멤버로 넣어줍니다.
            ClientData clientData = new ClientData(acceptClient);

            // BeginRead를 통해 비동기로 읽는다. (읽을 데이터가 올때까지 대기하지 않고 바로 아랫줄의 while문으로 이동한다.)
            clientData.client.GetStream().BeginRead(clientData.readByteData, 0, clientData.readByteData.Length, new System.AsyncCallback(DataReceived), clientData);

            while (true)
            {
                System.Console.WriteLine("서버 구동 중");
                System.Threading.Thread.Sleep(1000);
            }
        }

        private void DataReceived(System.IAsyncResult ar)
        {
            // 콜백메서드입니다. (피호출자가 호출자의 해당 메서드를 실행시켜줍니다)
            // 즉 데이터를 읽었을때 실행됩니다.

            // 콜백으로 받아온 Data를 ClientData로 형변환 합니다.
            ClientData callbackClient = ar.AsyncState as ClientData;

            // 실제로 넘어온 크기를 받아옵니다.
            int bytesRead = callbackClient.client.GetStream().EndRead(ar);

            // 문자열로 넘어온 데이터를 파싱해서 출력합니다.
            string readString = System.Text.Encoding.Default.GetString(callbackClient.readByteData, 0, bytesRead);

            System.Console.WriteLine(readString);

            // # 핵심
            // 비동기서버는 while문을 돌리지 않고 콜백메서드에서 다시 읽으라고 비동기명령을 내립니다.
            callbackClient.client.GetStream().BeginRead(callbackClient.readByteData, 0, callbackClient.readByteData.Length, new System.AsyncCallback(DataReceived), callbackClient);
        }
    }
    class ClientData
    {
        // 연결이 확인된 클라이언트를 넣어줄 클래스입니다.
        // readByteData는 stream데이터를 읽을 객체입니다.
        public System.Net.Sockets.TcpClient client { get; set; }
        public byte[] readByteData { get; set; }
        public ClientData(System.Net.Sockets.TcpClient client)
        {
            this.client = client;
            this.readByteData = new byte[1024];
        }
    }
}