﻿
namespace Example_TCP_Server
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("서버 콘솔창 \n\n\n");

            // TcpListener 생성자에 붙는 매개변수
            // 첫 번째 : 오픈할 서버 IP
            // 두 번째 : 오픈할 Port Number
            System.Net.Sockets.TcpListener server = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Any, 9999);

            // 서버를 시작합니다.
            server.Start();

            // 연결한 클라이언트를 받아옵니다.
            // 클라이언트 접속까지 서버는 기다립니다.
            System.Net.Sockets.TcpClient client = server.AcceptTcpClient();
            System.Console.WriteLine("클라이언트가 접속했습니다.");

            // 읽은 데이터를 출력 후 다음 데이터 읽기를 기다립니다.
            while (true)
            {
                // Socket은 byte[] 형식으로 데이터를 주고 받으므로 byte[]형 변수를 선언합니다.
                byte[] byteData = new byte[1024];

                // 클라이언트가 write한 데이터를 Read합니다.
                // 데이터 Read까지 대기하고, Read 후 데이터는 byteData에 저장됩니다.
                client.GetStream().Read(byteData, 0, byteData.Length);

                // 저장된 byteData의 출력을 위해 string으로 변경합니다.
                string strData = System.Text.Encoding.Default.GetString(byteData);

                // 읽어온 데이터가 byte Size보다 작은경우 빈 문자열을 제거합니다.
                int iEndpoint = strData.IndexOf('\0');
                string strParseMessage = strData.Substring(0, iEndpoint + 1);

                // 파싱된 데이터를 출력합니다.
                System.Console.WriteLine(strParseMessage);
            }
        }
    }
}
